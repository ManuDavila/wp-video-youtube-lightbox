<h3>Wordpress Video Youtube Lightbox Widget</h3> 

<p>You can add your favorites Youtube videos in a playlist from the admin panel widgets and display it in a responsive lightbox with a single click.</p>