=== Video Youtube Lightbox ===
Contributors: manudg
Donate link:https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=manudg_1%40msn%2ecom&lc=ES&item_name=manudg&no_note=0&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: youtube, playlist, widget, lightbox, responsive
Tested up to: 4.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

You can add your favorites Youtube videos in a playlist from the admin panel widgets.

== Description ==

You can add your favorites Youtube videos in a playlist from the admin panel widgets and display it in a responsive lightbox with a single click.

Major features in Video Youtube Lightbox include:

* Add to playlist many youtube videos as you want, just need the title and url of the video.
* Delete video option in the widget.
* Limits the number of videos to display in the widget.
* Play the video in a responsive lightbox.

== Installation ==

Upload the video-youtube-lightbox.zip file to your blog, Activate it.

== Changelog ==

= 1.0 =
*Release Date - 04th April, 2015*

* Previous version